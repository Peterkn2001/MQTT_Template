// Variables for outputting information about device config etc
String mqtt_client_id = String(client_id) + "_" + String(ESP.getChipId());
String short_filename = full_file_path.substring(full_file_path.lastIndexOf('\\')+1,full_file_path.length()); // Get just the filename from the end of the full filename path
String actual_ip_address;

// Variables used for Wi-Fi connection attempts etc...
int wifi_attempt_count = 0;                           // Count of how many times we've attempted to connect to the Wi-Fi
const int wait_between_wifi_attempts_millis = 500;    // How long we wait (in millis) before attempting to connect again
const int max_wifi_connect_attempts =          10;    // How many attempts we will have at connecting to the Wi-Fi before going into stand-alone maode
const int retry_wait_time_minutes =            10;    // How long (in minutes) we wait whne we're in stand-alone mode before trying to re-connect to Wi-Fi again
bool standalone_mode =                      false;    // flag to indicate if we're in stand-alone mode

// Variables for the RSSI heartbeat data and checking connections...
int heartbeat_millis;                                 // Will be assigned a random value in void setup
const int check_connection_millis = 30000;            // How often (in milliseconds) to check if MQTT is connected. Re-connection attempts take time, so 30,000 (30 seconds) millis works well  


// Variables to hold the timer ID's, so we can disable/enable them when needed...
int heartbeat_timer_id;
int check_connections_timer_id;
int send_serial_timer_id;
int long_delay_timout_id;


// Monitoring variables
int wifi_connect_count;               // Count of how may times we've connected to Wi-Fi since booting (should always be 1 or more)
int mqtt_connect_count;               // Count of how may times we've connected to the MQTT server since booting (should always be 1 or more)
unsigned long uptime;                 // Elapsed millis since booting (will reset to zero after 49 days)
char uptime_dd_hh_mm_ss [12];         // Character array to hold the uptime in Day:Hour:Minute:Second format
unsigned long last_uptime;            // Used to hold the last elapsed millis - used to detect a 49 day rollover
unsigned long rollover_count;         // Used to track the nuimber of 49 day rollovers since booting


// Sonoff S20 variables...
#define relay           12            // Sonoff S20 relay and blue LED are connected to GPIO 12 (LOW(0)=0ff, HIGH(1)=On)
#define physical_button  0            // Sonoff S20 pushbutton is connected to GPIO 0 (LOW(0)=Pushed, HIGH(1)=Released)
#define green_led       13            // Sonoff S20 Green LED is connected to GPIO 13 (LOW(0)=0n, HIGH(1)=Off)
int relay_state = LOW;                // Set the Relay Off (LOW)
unsigned long last_button_interrupt;  // the last time the output pin was toggled - Used for debounce
const int debounce_delay = 200;       // the debounce time in millis; increase if we get multiple on/offs when the button is pressed
