// THESE THREE VARIABLES SHOULD BE UNIQUE FOR EVERY DEVICE ON YOUR NETWORK !!!!!

char *client_id =                 "Sonoff_Test_Device_1";               // Used for OTA hostname and MQTT Client ID 
String base_mqtt_topic =          "Home/Room_1/Sonoff_1";               // Start of the MQTT Topic name used by this device
IPAddress device_ip               (192,168,1,123);                      // Static IP Address for the device

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

// Wi-Fi & Networking variables...
const char *ssid =                "xxxxxxxx"; 
const char *pass =                "xxxxxxxx";
IPAddress dns                     (192,168,1,1);
IPAddress gateway                 (192,168,1,1);
IPAddress subnet                  (255,255,255,0);

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

// MQTT Server Setting variables...
IPAddress mqtt_server_ip          (192,168,1,xxx);                       // IP Address for the MQTT Server...
const int mqtt_port =             1883;                                  // Port for the MQTT Server...
const char *mqtt_username =       "xxxxxxxx";                            // MQTT Server username...
const char *mqtt_password =       "xxxxxxxx";                            // MQTT Server password...

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

// Serial Monitor baud rate...
// Choose the baud rate that is the default for your MCU, so that MCU boot message aren't gobbledygook
const int serial_monitor_baud = 74880;
//const int serial_monitor_baud = 115200;
